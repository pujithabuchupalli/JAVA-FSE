
console.log("Welcome to the Community Portal");
window.onload = function() {
    alert("Page is fully loaded!");
};
